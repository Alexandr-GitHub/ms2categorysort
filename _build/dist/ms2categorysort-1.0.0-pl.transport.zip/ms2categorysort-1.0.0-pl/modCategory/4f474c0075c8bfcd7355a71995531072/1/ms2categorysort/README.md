# ms2categorysort

Per-category `menuindex` для MiniShop2 — отдельный MODX-компонент, не правит vendor MS2.

## Документация

- [INTEGRATION.md](docs/INTEGRATION.md) — установка addon
- [ARCHITECTURE.md](docs/ARCHITECTURE.md) — слои, стандарты (PSR-12, Clean Architecture)
- [FORK_MINISHOP2.md](docs/FORK_MINISHOP2.md) — влитие в fork MS2

## Быстрый старт

```bash
php tools/backup-ms2categorysort.php --key=ms2categorysort_backup_2026
# деплой файлов на сервер
php tools/install-ms2categorysort.php --key=ms2categorysort_install_2026
```

На странице категории: `&sortByCategory=`1`` (opt-in; без флага — поведение MS2).
